var str = '';
str += '<div id="DivID">';
str += '<object id="WebOffice" width="100%" height="100%" classid="clsid:8B23EA28-2009-402F-92C4-59BE0E063499" codebase="iWebOffice2009.cab#version=10,8,6,14">';
str += '</object>';
str += '</div>';
document.write(str);